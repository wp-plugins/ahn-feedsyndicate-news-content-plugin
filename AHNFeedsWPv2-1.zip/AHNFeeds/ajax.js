//alert("Hi...");

var showobj;

    function makeRequest(url,obj) {

		showobj=obj;

		

        var http_request = false;



        if (window.XMLHttpRequest) { // Mozilla, Safari, ...

            http_request = new XMLHttpRequest();

            if (http_request.overrideMimeType) {

                http_request.overrideMimeType('text/xml');

                // See note below about this line

            }

        } else if (window.ActiveXObject) { // IE

            try {

                http_request = new ActiveXObject("Msxml2.XMLHTTP");

            } catch (e) {

                try {

                    http_request = new ActiveXObject("Microsoft.XMLHTTP");

                } catch (e) {}

            }

        }



        if (!http_request) {

            alert('Giving up :( Cannot create an XMLHTTP instance');

            return false;

        }

        http_request.onreadystatechange = function() { alertContents(http_request); };

        http_request.open('GET', url, true);

        http_request.send(null);

    }



    function alertContents(http_request) {



        if (http_request.readyState == 4) {

            if (http_request.status == 200) {

			//alert(http_request.responseText);

                document.getElementById(showobj).innerHTML =  http_request.responseText;

            } else {

                alert('There was a problem with the request.');

            }

        }else{

			document.getElementById(showobj).innerHTML ='<br>Checking existing Records and Inserting New Records into Database......<br><img src="../wp-content/plugins/AHNFeeds/loading.gif"><br>';

		}

		

		

    }

	

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



		

	

	function import_data_from_csv(db,user,pass,hst,pref,categ,picpic){

	





	//	var region= document.getElementById("region").value;

		//var coupon= document.getElementById("coupon").value;

//makeRequest('../wp-content/plugins/AHNFeeds/ajax_resp_file.php?db='+db+'&user='+user+'&pass='+pass+'&hst='+hst+'&pref='+pref,'import_div');

	

makeRequest('../wp-content/plugins/AHNFeeds/ajax_resp_file.php?db='+db+'&user='+user+'&pass='+pass+'&hst='+hst+'&pref='+pref+'&categ='+categ+'&picpic='+picpic,'import_div');

	

	}

	

function refreshAll(){
	makeRequest('../wp-content/plugins/AHNFeeds/cron.php','import_div');
}

function refreshAllPending(){
	makeRequest('../wp-content/plugins/AHNFeeds/cron.php?status=pending','import_div');
}

