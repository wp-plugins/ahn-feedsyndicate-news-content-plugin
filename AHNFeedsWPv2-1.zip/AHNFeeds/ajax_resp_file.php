<?php

/*

Component of AHN Feeds WordPress Plugin
(c) Copyright AllHeadlineNews

*/

include("../../../wp-config.php");
global $wpdb;

//echo "g array...<br>";

$prefix = $wpdb->prefix;

//print_r($_GET);




//$query="select * from wp-posts";

//mysql_connect($_GET[hst],$_GET[user],$_GET[pass]);
//$_GET[db];

$getDatacategory = $_GET['categ'];
$picpic = $_REQUEST['picpic'];

//mysql_select_db($_GET[db]);
//mysql_query($query);
ob_start();

include("common_files/sitefunction.php");
/////////////////////////////////////////////////

set_time_limit(0);
ini_set("upload_max_filesize","20M");
ini_set("post_max_size","20M");

$rows = 1;
$t_records=0;
$t_cats=0;
$matchcount = 0;


if($_GET['autoupdate'] == "automatic")
{
	$all_query = mysql_query("Select * from ".$wpdb->prefix."xml");
	while($all_xml_result = mysql_fetch_array($all_query))
	{
		$completexmlpath = $all_xml_result['xml_path'];
		$completexmlcat = $all_xml_result['xml_cat'];

		$search_results = file_get_contents($all_xml_result['xml_path']);
		$result_array[0]=array();
		$i=0;

		$search_results= str_replace('&','*',$search_results);
		$xml = xml2array($search_results,1);
		$key_word = "";

		if($key_word=='')
		{
			$result_array=$xml['NewsML']['NewsItem'];
		}

		$_SESSION['result_array']=$result_array;
		if(isset($_GET['id']))
		$id=$_GET['id'];
		if($id=='')
		{
			$id=0;
		}

		$count = 0;

		if($completexmlcat != '')
		{
			$cat_query = mysql_query("SELECT * FROM ".$prefix."terms where term_id='$getDatacategory' ");
			$res_cats = mysql_fetch_array($cat_query);
			$Datacategory = $res_cats['name'];
		}
		else
		{
			$Datacategory = "Uncategorized";
		}
		//}

		foreach($xml['NewsML']['NewsItem'] as $vals)
		{

			$headline = str_replace('*','&',$vals['NewsComponent']['NewsLines']['HeadLine']['value']);
			$headline = str_replace('&amp;quot;','&amp;&quot;',$headline);
			echo $headline.'<br>';
			$Dateid = str_replace('*','&',$vals['Identification']['NewsIdentifier']['DateId']['value']);
			$image=($vals['NewsComponent']['NewsComponent'][2]['NewsComponent']['ContentItem']['attr']['Href']);
			foreach($xml['NewsML']['NewsItem'][$count]['NewsComponent']['NewsComponent'] as $valss)
			{
					
				$DataContent = str_replace('*','&',$valss['ContentItem']['DataContent']['value']);
				$DataContent .= print_r($valss['ContentItem']);
					
				if ($image!="" && strpos($image,'.jpg') ){
					$DataContent ="<img width=\'40%\' alt=\'None\' src=\'$image\' title=\'Story Image Manual Upload\' class=\'alignleft\'>".$DataContent;
				}
				break;
			}

			if($headline!=''&&$Dateid!=''&&$DataContent!=''&&$Datacategory!='' )
			{

				$query_check="SELECT * FROM ".$prefix."posts where post_title = '".$headline."'";
				$res_check=mysql_query($query_check);

				if($res_check)
				$totalmatchrecord = mysql_num_rows($res_check);
				$matchcount = $matchcount + $totalmatchrecord;

				if($totalmatchrecord > 0)
				{
					if($res_check)
					$row_pst = mysql_fetch_array($res_check);
					$post_id=$row_pst[ID];

					$query_check_term="SELECT ".$prefix."terms.name,
			".$prefix."term_taxonomy.taxonomy,
			".$prefix."term_taxonomy.term_taxonomy_id,
			".$prefix."terms.term_id
			FROM
			".$prefix."terms Inner Join ".$prefix."term_taxonomy ON ".$prefix."terms.term_id = ".$prefix."term_taxonomy.term_id and taxonomy= 'category' and name='".$Datacategory."'";

					$res_check_term=mysql_query($query_check_term);

					if(mysql_num_rows($res_check_term)==0)
					{
						$qry_insert_term="insert into ".$prefix."terms set
									name='".$Datacategory."',
									slug='".$Datacategory."'";
							
						mysql_query($qry_insert_term);
						$term_id=mysql_insert_id();

						if($term_id!='')
						{
							$qry_insert_tax="insert into ".$prefix."term_taxonomy set term_id=".$term_id.",
																							count=1,
																							taxonomy = 'category'";

							mysql_query($qry_insert_tax);
							$term_taxonomy_id= mysql_insert_id();

							$qry_insert_post="insert into ".$prefix."term_relationships set object_id=".$post_id.",
																					term_taxonomy_id=".$term_taxonomy_id;


							mysql_query($qry_insert_post);
							$t_cats++;
						}
					}
					else
					{
						$row_tm=mysql_fetch_array($res_check_term);
						$term_taxonomy_id= $row_tm["term_taxonomy_id"];
						$query_check_p_t="SELECT * FROM ".$prefix."term_relationships where object_id = ".$post_id." and 	term_taxonomy_id=".$term_taxonomy_id;

						$res_p_t = mysql_query($query_check_p_t);
						if($res_p_t)
						$sec_cont = mysql_num_rows($res_p_t);

						if($sec_cont > 0)
						{
							continue;
						}
						else
						{
							if($term_taxonomy_id!='')
							{
								$qry_update_tax="update ".$prefix."term_taxonomy set count=count+1 where term_taxonomy_id= ".$term_taxonomy_id;
								mysql_query($qry_update_tax);
							}

							$qry_insert_post="insert into ".$prefix."term_relationships set object_id=".$post_id.",
																			term_taxonomy_id=".$term_taxonomy_id;


							mysql_query($qry_insert_post);
							$t_cats++;
						}
					}
				}
				else
				{
		   if($Datacategory!='')
		   {
		   	$query_check_term="SELECT
				".$prefix."terms.name,
				".$prefix."term_taxonomy.taxonomy,
				".$prefix."term_taxonomy.term_taxonomy_id,
				".$prefix."terms.term_id
				FROM
				".$prefix."terms
				Inner Join ".$prefix."term_taxonomy ON ".$prefix."terms.term_id = ".$prefix."term_taxonomy.term_id and taxonomy= 'category' and name='".$Datacategory."'";

		   	$res_check_term=mysql_query($query_check_term);
		   	if(mysql_num_rows($res_check_term)==0)
		   	{
		   		$qry_insert_term="insert into ".$prefix."terms set
					name='".$Datacategory."',
					slug='".$Datacategory."'";

		   		mysql_query($qry_insert_term);
		   		$term_id=mysql_insert_id();

		   		if($term_id!='')
		   		{
		   			$qry_insert_tax="insert into ".$prefix."term_taxonomy set
						term_id=".$term_id.",
						count=1,
						taxonomy = 'category'";

		   			mysql_query($qry_insert_tax);
		   			$term_taxonomy_id= mysql_insert_id();
		   		}
		   	}
		   	else
		   	{
		   		$row=mysql_fetch_array($res_check_term);
		   		$term_id=$row["term_id"];
		   		$term_taxonomy_id= $row["term_taxonomy_id"];

		   		if($term_taxonomy_id!='')
		   		{
		   			$qry_update_tax="update ".$prefix."term_taxonomy set
						count=count+1 where term_taxonomy_id= ".$term_taxonomy_id;

		   			mysql_query($qry_update_tax);
		   		}
		   	}
		   }

		   if($data[3]!='')
		   {

		   	$query_check_term="SELECT
				".$prefix."terms.name,
				".$prefix."term_taxonomy.taxonomy,
				".$prefix."term_taxonomy.term_taxonomy_id,
				".$prefix."terms.term_id
				FROM
				".$prefix."terms
	
				Inner Join ".$prefix."term_taxonomy ON ".$prefix."terms.term_id = ".$prefix."term_taxonomy.term_id and taxonomy= 'post_tag' and name='".addslashes($data[3])."'";

		   	$res_check_term=mysql_query($query_check_term);

		   	if(mysql_num_rows($res_check_term)==0)
		   	{
		   		$qry_insert_term="insert into ".$prefix."terms set
					name='".addslashes($data[3])."',
					slug='". strtolower(str_replace(' ','-',addslashes($data[3])))."'";

		   		mysql_query($qry_insert_term);
		   		$term_tg_id=mysql_insert_id();

		   		if($term_tg_id!='')
		   		{
		   			$qry_insert_tax="insert into ".$prefix."term_taxonomy set
						term_id=".$term_tg_id.",
						count=1,
						taxonomy = 'post_tag'";

		   			mysql_query($qry_insert_tax);
		   			$term_tg_taxonomy_id = mysql_insert_id();
		   		}
		   	}
		   	else
		   	{
		   		$row=mysql_fetch_array($res_check_term);
		   		$term_tg_id=$row["term_id"];
		   		$term_tg_taxonomy_id= $row["term_taxonomy_id"];


		   		if($term_tg_taxonomy_id!='')
		   		{
		   			$qry_update_tax="update ".$prefix."term_taxonomy set
						count=count+1 where term_taxonomy_id= ".$term_tg_taxonomy_id;
		   			mysql_query($qry_update_tax);
		   		}
		   	}
		   }

		   $qry_insert_tax="insert into ".$prefix."posts set
			post_title='".$headline."',
			post_date='".$Dateid."',
			post_content='".$DataContent."'";


		   mysql_query($qry_insert_tax);

		   $post_id= mysql_insert_id();
			  $t_records++;
			  if($Datacategory!='')
			  {
			  	$qry_insert_post="insert into ".$prefix."term_relationships set
			object_id=".$post_id.",
			term_taxonomy_id=".$term_taxonomy_id;

			  	mysql_query($qry_insert_post);

			  }
			  if($data[3]!='')
			  {
			  	$qry_insert_post="insert into ".$prefix."term_relationships set
			object_id=".$post_id.",
			term_taxonomy_id=".$term_tg_taxonomy_id;

			  	mysql_query($qry_insert_post);

			  }
				}// end outer else
			}//end outer if after while(data[0]...)

			$count = $count + 1;
		}

	}


}
else
{

	// This part responds to REFRESH button
	$path_get_query = mysql_query("Select * from ".$wpdb->prefix."xml where ID='$picpic' ");
	$path_get_res = mysql_fetch_array($path_get_query);
	$search_results = file_get_contents($path_get_res['xml_path']);
	$result_array[0]=array();
	$i=0;

	$search_results= str_replace('&','*',$search_results);
	$xml = xml2array($search_results,1);
	$key_word = "";

	if($key_word=='')
	{
		$result_array=$xml['NewsML']['NewsItem'];
	}


	$_SESSION['result_array']=$result_array;
	if(isset($_GET['id']))
	$id=$_GET['id'];
	if($id=='')
	{
		$id=0;
	}

	$count = 0;

	/*
	 if($getDatacategory != '')
	 {

	 $cat_query = mysql_query("SELECT * FROM ".$prefix."terms where term_id='$getDatacategory' ");
	 $res_cats = mysql_fetch_array($cat_query);
	 $Datacategory = $res_cats['name'];
	 }
	 else
	 {
	 $Datacategory = "Uncategorized";
	 }
	 */

	$catSql="SELECT * FROM ".$prefix."terms where term_id='{$path_get_res['xml_cat']}' ";
	$catQuery=mysql_query($catSql);
	$catRow=mysql_fetch_array($catQuery);
	$Datacategory=$catRow['name'];

	//---------------------
	foreach($xml['NewsML']['NewsItem'] as $vals)
	{

		$headline = str_replace('*','&',$vals['NewsComponent']['NewsLines']['HeadLine']['value']);
		$headline = str_replace('&amp;quot;','&amp;&quot;',$headline);

		$Dateid = str_replace('*','&',$vals['Identification']['NewsIdentifier']['DateId']['value']);

		$image = '';
		$story = '';
		$summary = '';

		# $vals['NewsComponent']['NewsLines']
		# $vals['NewsComponent']['NewsComponent'] - array of arrays, identify which is which by contents

		foreach($vals['NewsComponent']['NewsComponent'] as $component)
		{
			//echo "<hr><pre>";
			//print_r($component);
			//echo "</pre>";

			// What is it?
			if ( array_key_exists('Role', $component) ) {
				# Summary
				$summary = $component['ContentItem']['DataContent']['value'];
			} elseif ( array_key_exists('ContentItem', $component) ) {
				# story
				$story = $component['ContentItem']['DataContent']['value'];
			} elseif ( array_key_exists('NewsComponent', $component) ) {
				# attachment (image)
				$caption = '';
				foreach ( $component['NewsComponent']  as $subitem ) {
					if ($subitem['Role']['attr']['FormalName'] == 'Caption') {
						$caption = $subitem['ContentItem']['DataContent']['value'];
					} elseif ($subitem['Role']['attr']['FormalName'] == 'JPG') {
						$image = $subitem['ContentItem']['attr']['Href'];
					}
				}
			}

			//$DataContent = str_replace('*','&',$valss['ContentItem']['DataContent']['value']);

			if ($story!=""){
				$DataContent =str_replace('*lt;','<',$story);
				$DataContent =str_replace('*gt;','>',$DataContent);
			}

			if ($image!="" && strpos($image,'.jpg')){
				$DataContent ="<img width=\'40%\' alt=\'None\' src=\'$image\' title=\'Story Image Manual Upload\' class=\'alignleft\'>".$DataContent;
				#echo $DataContent;
			}
		}


		# got a story
		$story =str_replace('*lt;','<',$story);
		$story =str_replace('*gt;','>',$story);

		if ($image != '') {
			$story="<img width='40%' alt='None' src='$image' title='" . addslashes($caption) . "' class='alignleft'>".$story;
		}

		# this is easier than changing his ugly code below
		$DataContent = $story;

		// This section seems to handle taxonomy

		if($headline!=''&&$Dateid!=''&&$DataContent!=''&&$Datacategory!='' )
		{
			$query_check="SELECT * FROM ".$prefix."posts where post_title = '".$headline."'";
			$res_check=mysql_query($query_check);

			if($res_check) {
				$totalmatchrecord = mysql_num_rows($res_check);
			}

			if($totalmatchrecord > 0)
			{
				if($res_check) {
					$row_pst = mysql_fetch_array($res_check);
				}
				$post_id=$row_pst[ID];

				$query_check_term="SELECT ".$prefix."terms.name,".$prefix."term_taxonomy.taxonomy,".$prefix."term_taxonomy.term_taxonomy_id,".$prefix."terms.term_id FROM ".$prefix."terms
		Inner Join ".$prefix."term_taxonomy ON ".$prefix."terms.term_id = ".$prefix."term_taxonomy.term_id and taxonomy= 'category' and name='".$Datacategory."'";

				$res_check_term=mysql_query($query_check_term);

				if(mysql_num_rows($res_check_term)==0)
				{
					$qry_insert_term="insert into ".$prefix."terms set
								name='".$Datacategory."',
								slug='".$Datacategory."'";

					mysql_query($qry_insert_term);
					$term_id=mysql_insert_id();

					if($term_id!='')
					{
						$qry_insert_tax="insert into ".$prefix."term_taxonomy set term_id=".$term_id.",
																						count=1,
																						taxonomy = 'category'";

						mysql_query($qry_insert_tax);
						$term_taxonomy_id= mysql_insert_id();

						$qry_insert_post="insert into ".$prefix."term_relationships set object_id=".$post_id.",
																				term_taxonomy_id=".$term_taxonomy_id;


						mysql_query($qry_insert_post);
						$t_cats++;
					}
				}
				else
				{
					$row_tm=mysql_fetch_array($res_check_term);
					$term_taxonomy_id= $row_tm["term_taxonomy_id"];
					$query_check_p_t="SELECT * FROM ".$prefix."term_relationships where object_id = ".$post_id." and 	term_taxonomy_id=".$term_taxonomy_id;

					$res_p_t = mysql_query($query_check_p_t);
					if($res_p_t) {
						$sec_cont = mysql_num_rows($res_p_t);
					}

					if($sec_cont > 0)
					{
						continue;
					}
					else
					{
		 			if($term_taxonomy_id!='')
		 			{
		 				$qry_update_tax="update ".$prefix."term_taxonomy set count=count+1 where term_taxonomy_id= ".$term_taxonomy_id;
		 				mysql_query($qry_update_tax);
		 			}

		 			$qry_insert_post="insert into ".$prefix."term_relationships set object_id=".$post_id.",
																		term_taxonomy_id=".$term_taxonomy_id;

	 				mysql_query($qry_insert_post);
	 				$t_cats++;
					}
				}
			}
			else
			{
	   if($Datacategory!='')
	   {
	   	$query_check_term="SELECT
			".$prefix."terms.name,
			".$prefix."term_taxonomy.taxonomy,
			".$prefix."term_taxonomy.term_taxonomy_id,
			".$prefix."terms.term_id
			FROM
			".$prefix."terms
			Inner Join ".$prefix."term_taxonomy ON ".$prefix."terms.term_id = ".$prefix."term_taxonomy.term_id and taxonomy= 'category' and name='".$Datacategory."'";

	   	$res_check_term=mysql_query($query_check_term);
	   	if(mysql_num_rows($res_check_term)==0)
	   	{
	   		$qry_insert_term="insert into ".$prefix."terms set
				name='".$Datacategory."',
				slug='".$Datacategory."'";

	   		mysql_query($qry_insert_term);
	   		$term_id=mysql_insert_id();

	   		if($term_id!='')
	   		{
	   			$qry_insert_tax="insert into ".$prefix."term_taxonomy set
					term_id=".$term_id.",
					count=1,
					taxonomy = 'category'";

	   			mysql_query($qry_insert_tax);
	   			$term_taxonomy_id= mysql_insert_id();
	   		}
	   	}
	   	else
	   	{
	   		$row=mysql_fetch_array($res_check_term);
	   		$term_id=$row["term_id"];
	   		$term_taxonomy_id= $row["term_taxonomy_id"];

	   		if($term_taxonomy_id!='')
	   		{
	   			$qry_update_tax="update ".$prefix."term_taxonomy set count=count+1 where term_taxonomy_id= ".$term_taxonomy_id;

	   			mysql_query($qry_update_tax);
	   		}
	   	}
	  	}

	  	if($data[3]!='')
	  	{

	  		$query_check_term="SELECT
			".$prefix."terms.name,
			".$prefix."term_taxonomy.taxonomy,
			".$prefix."term_taxonomy.term_taxonomy_id,
			".$prefix."terms.term_id
			FROM
			".$prefix."terms

			Inner Join ".$prefix."term_taxonomy ON ".$prefix."terms.term_id = ".$prefix."term_taxonomy.term_id and taxonomy= 'post_tag' and name='".addslashes($data[3])."'";

	  		$res_check_term=mysql_query($query_check_term);

	  		if(mysql_num_rows($res_check_term)==0)
	  		{
	  			$qry_insert_term="insert into ".$prefix."terms set
				name='".addslashes($data[3])."',
				slug='". strtolower(str_replace(' ','-',addslashes($data[3])))."'";

	  			mysql_query($qry_insert_term);
	  			$term_tg_id=mysql_insert_id();

	  			if($term_tg_id!='')
	  			{
	  				$qry_insert_tax="insert into ".$prefix."term_taxonomy set
					term_id=".$term_tg_id.",
					count=1,
					taxonomy = 'post_tag'";

	  				mysql_query($qry_insert_tax);
	  				$term_tg_taxonomy_id = mysql_insert_id();
	  			}
	  		}
	  		else
	  		{
	  			$row=mysql_fetch_array($res_check_term);
	  			$term_tg_id=$row["term_id"];
	  			$term_tg_taxonomy_id= $row["term_taxonomy_id"];


	  			if($term_tg_taxonomy_id!='')
	  			{
	  				$qry_update_tax="update ".$prefix."term_taxonomy set
					count=count+1 where term_taxonomy_id= ".$term_tg_taxonomy_id;
	  				mysql_query($qry_update_tax);
	  			}
	  		}
	 	 }

	 	 $qry_insert_post="insert into ".$prefix."posts set
		post_title='".addslashes($headline)."',
		post_date='".$Dateid."',
		post_content='".addslashes($DataContent)."'";

	 	 mysql_query($qry_insert_post);

	   $post_id= mysql_insert_id();

		  $t_records++;
		  if($Datacategory!='')
		  {
		  	$qry_insert_post="insert into ".$prefix."term_relationships set
		object_id=".$post_id.",
		term_taxonomy_id=".$term_taxonomy_id;

		  	mysql_query($qry_insert_post);

		  }
		  if($data[3]!='')
		  {
		  	$qry_insert_post="insert into ".$prefix."term_relationships set
		object_id=".$post_id.",
		term_taxonomy_id=".$term_tg_taxonomy_id;

		  	mysql_query($qry_insert_post);

		  }
			}// end outer else
		}//end outer if after while(data[0]...)

		$count = $count + 1;


	}
	//---------------------




}

if($t_cats!=0)
{
	echo "<br><b>".$t_cats." post categories updated</b><br>";
}
if($_GET['autoupdate'] == "automatic")
{
}
else
{
	echo "<b>".$t_records." records inserted into database</b>";//$matchcount;
}
?>