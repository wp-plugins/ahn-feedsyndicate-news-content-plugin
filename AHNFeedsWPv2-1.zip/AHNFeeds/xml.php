<?php

/*

Component of AHN Feeds WordPress Plugin
(c) Copyright AllHeadlineNews

*/

header('Content-type: text/xml');
/*include("common_files/siteconfig.php");
	include('tables/tables.php');
	include("common_files/mysql-class.php");
	include("common_files/sitefunction.php");*/
//mysql_connect('db102.perfora.net','dbo107043739','clarity123');
include("../../../wp-config.php");

//mysql_connect($_POST[hst],$_POST[user],$_POST[pass]);
//mysql_select_db($_POST[db]);
global $wpdb;
global $post;



 ?> 
<!--<![CDATA[<?php //echo substr(htmlentities(strip_tags($postrecord_res['post_content'],'ENT_QUOTES')),0,348); ?>]]>-->



<NewsML>
	<NewsEnvelope>
		<DateAndTime>20100901T025855-04:00</DateAndTime>
	</NewsEnvelope>

<?php
$cate = $_GET['cat'];
query_posts("cat=".$cate);
if ( have_posts() ) while ( have_posts() ) : the_post(); 
$i++;
?>
<NewsItem>

	<Identification>
		<NewsIdentifier>
			<DateId><![CDATA[<?php echo $post->post_date; ?>]]></DateId>
		</NewsIdentifier>
	</Identification>
	
	<NewsComponent>
		<NewsLines>
			<HeadLine><![CDATA[<?php echo $post->post_title; ?>]]></HeadLine>
		</NewsLines>	
		
		<NewsComponent>
			<ContentItem>
				<DataContent>
					<![CDATA[<?php echo $post->post_content; ?>]]>
				</DataContent>
			</ContentItem>
		</NewsComponent>	
		<NewsComponent>
			<ContentItem>
				<DataContent>
					<![CDATA[<?php echo $post->post_content; ?>]]>
				</DataContent>
			</ContentItem>
		</NewsComponent>	
	</NewsComponent>
	
</NewsItem>
<?php endwhile; ?>  
</NewsML>

