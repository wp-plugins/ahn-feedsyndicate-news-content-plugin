<?php
ob_start();
	/*
	Plugin Name: AHN Feeds
	Plugin URI: http://www.allheadlinenews.com/software
	Description: Plugin to import data from NewsML to wordpress database. Copyright AHN
	Version: 2.0
	Author: All Headline News
	Author URI: http://www.feedsyndicate.com
	*/

	// Hook for adding admin menus

	add_action('admin_menu', 'mt_add_pages');
	global $wpdb;
	
		
	#################################################Check If table Exists ###########################################
	function getCategoryName($xml_cat)
	{
		// get name form id. what's my db object
		global $wpdb;
		$sql="SELECT name FROM `wp_terms` WHERE `term_id`='$xml_cat'";
		$row = $wpdb->get_row($sql);
		#return $sql; //$row['name'];
		return $row->name;
		

	}
	
	function table_exists($table)
	{
	
	$result = mysql_list_tables(DB_NAME) or die(mysql_error());
	while ($row = mysql_fetch_row($result)) {
	if($row[0]==$table)
	{
	return true;
	}
	}
	return false;
	}
	
	if(!table_exists($wpdb->prefix."xml"))
		{
			$qry_create_table="CREATE TABLE IF NOT EXISTS ".$wpdb->prefix."xml (
			  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			  `xml_path` text NOT NULL,
			  `xml_title` text NOT NULL,
			  `xml_cat` varchar(255) NOT NULL,
			  PRIMARY KEY (`ID`)
			)"; 
			$wpdb->query($qry_create_table);
		}
	


	function ps_xml_front_end()
	{
?>

<form action="<?php echo get_option('home') ?>/wp-content/plugins/AHNFeeds/xml.php" method="get" name="makexml" id="makexml">
  <table width='400' height='95' style='border:1px solid black;padding:10px;' bordercolor='#000000' >
    <tr>
      <td colspan="3" style="font-size:18px;"><strong>Create NewsML Feed</strong> </td>
    </tr>
    <tr>
      <td width='120'><!--<strong>Select Category</strong>:--></td>
      <td colspan='2'><!--<?php wp_dropdown_categories('hide_empty=0'); ?>--></td>
    </tr>
    <tr>
      <td width='120'></td>
      <td colspan='2'><input type="submit" name="makexmlbtn" id="makexmlbtn" value="Submit" /></td>
    </tr>
  </table>
</form>
<?php	
	}
	add_shortcode('xmlgenerate', 'ps_xml_front_end');
	
	
	// action function for above hook

	function mt_add_pages() 
	{
		// Add a new submenu under Options:

	// Add a new top-level menu (ill-advised):

	add_menu_page('xmltomysql', 'AHNFeeds', 8, __FILE__, 'add_xmltomysql');


	// Add a submenu to the custom top-level menu:

	//add_submenu_page(__FILE__, 'Import', 'Import', 8, 'add_xmltomysql', 'add_xmltomysql');
	//add_submenu_page(__FILE__, 'View xmltomysql', 'View xmltomysql', 8, 'view_xmltomysql', 'view_xmltomysql');

	// Add a second submenu to the custom top-level menu:
	//  add_submenu_page(__FILE__, 'Test Sublevel 2', 'Test Sublevel 2', 8, 'sub-page2', 'mt_sublevel_page2');
	}

	// member_options() displays the page content for the Test Options submenu

	function member_options() 
	{
		echo "<h2>Member Options</h2>";
	}

	// mt_manage_page() displays the page content for the Test Manage submenu

	function mt_manage_page() 
	{
		echo "<h2>Test Manage</h2>";
	}

	// add_xmltomysql() displays the page content for the custom Test Toplevel menu

	function add_xmltomysql() 
	{

	//ini_set('error_reporting', '2047');

	//ini_set('display_errors', '1');

	global $wpdb;

	if($_POST['Delete'])
	{
		$xml_delete_id = $_POST['xml_del_id'];
		mysql_query("Delete from ".$wpdb->prefix."xml where ID='$xml_delete_id' ");
	}

	if($_POST['Upload'])
	{
		$pic = "newsml.xml";
		
		if($_POST["pic2"] != '')
		{

			$picpic = $_POST["pic2"];
			$xml_title=$_POST['xml_title'];	
			$category_new = $_POST['cat'];		

			$insert_xml_record = mysql_query("insert into ".$wpdb->prefix."xml set xml_path='$picpic',xml_cat='$category_new',`xml_title`='$xml_title'");

			move_uploaded_file($_FILES['pic']['tmp_name'],"../wp-content/uploads/".$pic);

		}	
	}//end post	

	?>
<div class="wrap">
  <h2>ADD NewsML Feed</h2>
  <?php if($_GET[msg]=='add_success'){?>
  <div class="updated fade below-h2" id="message" style="background-color: rgb(255, 251, 204);">
    <p>User added.</p>
  </div>
  <?php }?>
  <?php 

	if($error_msg!='')
		{ 
	?>
  <div class="updated fade below-h2" id="message" style="background-color: rgb(255, 251, 204);">
    <p><?php echo $error_msg; ?>.</p>
  </div>
  <?php 

		}

	?>
  <form action="" method="post" id="addmember" name="addmember" enctype="multipart/form-data">
    <input type="hidden" value="29d93e8c23" name="_wpnonce" id="_wpnonce"/>
    <input type="hidden" value="/wp27/wp-admin/link-add.php" name="_wp_http_referer"/>
    <input type="hidden" value="5adf633704" name="closedpostboxesnonce" id="closedpostboxesnonce"/>
    <input type="hidden" value="0338fd8df9" name="meta-box-order-nonce" id="meta-box-order-nonce"/>
    <div class="metabox-holder" id="poststuff">
      <div class="has-sidebar" id="post-body">
        <div class="has-sidebar-content" id="post-body-content">
          <div class="meta-box-sortables ui-sortable" id="normal-sortables" style="position: relative;">
            <div class="postbox" id="linkadvanceddiv">
              <div title="Click to toggle" class="handlediv"><br/>
              </div>
              <h3 class="hndle"><span>Add New Feed - Settings</span></h3>
              <div class="inside">
                <?php

	if($_GET['action']=='edit')
	{

	$query_edit="Select * from ".$wpdb->prefix."members where id=".$_GET[id];
	$row_edit = $wpdb->get_row($query_edit) or die("unable to execute query".mysql_error());

	}

	?>
                <table cellspacing="2" cellpadding="5" style="width: 100%;" class="form-table">
                  <tbody>
                    <script type="text/javascript" src="<?php echo get_option('home') ?>/wp-content/plugins/AHNFeeds/ajax.js"></script>
                    <tr>
                      <td width="21%"><strong>Enter the NewsML Feed URL:</strong></td>
                      <td width="79%"><input type="text" style="width:250px;" name="pic2" /></td>
                    </tr>
                    <tr>
                      <td width="21%"><strong>Title of  NewsML Feed :</strong></td>
                      <td width="79%"><input type="text" style="width:250px;" name="xml_title" /></td>
                    </tr>					
                    <tr>
                      <td width="80"><strong>Store this feed in Category</strong>:</td>
                      <td colspan="2"><?php wp_dropdown_categories('hide_empty=0'); ?>
                      </td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td><input type="submit" value="Add Feed" name="Upload" id="Upload" /></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="meta-box-sortables ui-sortable" id="advanced-sortables" style="position: relative;"> </div>
          <input type="hidden" value="add" name="action"/>
        </div>
      </div>
    </div>
  </form>
</div>
      <div id="import_div" style="width:100%;height:150px; text-align:center;"> <br />
        <br />
      </div>
<table>
  <tr>
    <td colspan="2"><table width="850" height="95" style="border:1px solid black;" bordercolor="#000000" >
        <tr>
          <td colspan=5><input type="submit" name="RefreshAll" value="Refresh All" onclick="return refreshAll();">&nbsp;<input type="submit" name="RefreshAllPending" value="Refresh All But Do not Publish" onclick="return refreshAllPending();"></td>
          <td colspan="2"><!--<?php wp_dropdown_categories('hide_empty=0'); ?>-->
          </td>
        </tr>
        <tr>
          <td colspan="5" style="background-color:#999999;"><strong>XML File Record</strong></td>
        </tr>
        <tr>
          <td style="border:1px solid black;" width="80"><div align="center"><strong>ID</strong></div></td>
		  <td style="border:1px solid black;" width="80"><div align="center"><strong>Title</strong></div></td>
		  <td style="border:1px solid black;" width="80"><div align="center"><strong>Category</strong></div></td>
          <td style="border:1px solid black;" width="479"><div align="center"><strong>XML File Path</strong></div></td>
          <td style="border:1px solid black;" width="179"><div align="center"><strong>Action</strong></div></td>
        </tr>
        <?php 
		$xml_record = mysql_query("Select * from ".$wpdb->prefix."xml");
		while($xml_rec_res = mysql_fetch_array($xml_record))
		{
		?>
        <tr>
          <td align="center" valign="top" style="border:1px solid black;"><?php echo $xml_rec_res['ID']?></td>
		  <td align="center" valign="top" style="border:1px solid black;"><?php echo $xml_rec_res['xml_title']?></td>
		  <td align="center" valign="top" style="border:1px solid black;"><?php echo getCategoryName($xml_rec_res['xml_cat'])?></td>
          <td valign="top" style="border:1px solid black;" ><?php echo $xml_rec_res['xml_path']?></td>
          <td style="border:1px solid black;"><table width="177">
              <tr>
                <td valign="top" align="center"><!--<form name="refresh_<?php echo $xml_rec_res['ID']?>" id="refresh_<?php echo $xml_rec_res['ID']?>" method="post" action="">-->
                  <input type="submit" value="Refresh" name="Refresh" id="<?php echo $xml_rec_res['ID']?>" onclick="return import_data_from_csv(<?php echo "'".DB_NAME."','".DB_USER."',"."'".DB_PASSWORD."'".",'".DB_HOST."','".$wpdb->prefix."'"; ?>,document.getElementById('cat').value,'<?php echo $xml_rec_res['ID']?>')"  />
                  <input type="hidden" value="<?php echo $xml_rec_res['ID']?>" name="xml_id" id="xml_id" />
                  <!--</form>-->
                </td>
                <td valign="top"><form name="delete_<?php echo $xml_rec_res['ID']?>" id="delete_<?php echo $xml_rec_res['ID']?>" method="post" action="">
                    <input type="submit" value="Delete" name="Delete" id="Delete" />
                    <input type="hidden" value="<?php echo $xml_rec_res['ID']?>" name="xml_del_id" id="xml_del_id" />
                  </form></td>
              </tr>
            </table></td>
        </tr>
        <?php



		}



		?>
      </table></td>
  </tr>
  <tr>
    <td colspan="2"><!--Checking existing Records and Inserting New Records into Database......-->
      <br />

      <script language="javascript">



	



	//import_data_from_csv(<?php echo "'".DB_NAME."','".DB_USER."',"."'".DB_PASSWORD."'".",'".DB_HOST."','".$wpdb->prefix."','".$categ."','".picpic."'"; ?>);</script>
    </td>
  </tr>
</table>
<?php 







	}







	







	// mt_sublevel_page() displays the page content for the first submenu







	// of the custom Test Toplevel menu







	function view_xmltomysql() {







	







	global $wpdb;







	







	







	//print_r($_POST);







	







	?>
<div class="wrap">
  <div class="icon32" id="icon-edit"><br/>
  </div>
  <h2>Edit Members</h2>
  <?php if($_GET[msg]=='delete_success'){ ?>
  <div class="updated fade below-h2" id="message" style="background-color: rgb(255, 251, 204);">
    <p>Record(s) successfully deleted.</p>
  </div>
  <?php }







	







	if($_GET[msg]=='edit_success'){ ?>
  <div class="updated fade below-h2" id="message" style="background-color: rgb(255, 251, 204);">
    <p>User edited.</p>
  </div>
  <?php } ?>
  <form method="POST" action="" id="posts-filter">
    <ul class="subsubsub">
      <li><a class="current" href="edit.php">All <span class="count">(6)</span></a> |</li>
    </ul>
    <input type="hidden" value="list" name="mode"/>
    <div class="tablenav">
      <div class="alignleft actions">
        <select name="action">
          <option selected="selected" value="-1">Bulk Actions</option>
          <option value="edit">Edit</option>
          <option value="delete">Delete</option>
        </select>
        <input type="submit" class="button-secondary action" id="doaction" name="doaction" value="Apply"/>
        <input type="hidden" value="8aa924000d" name="_wpnonce" id="_wpnonce"/>
        <input type="hidden" value="/wp27/wp-admin/edit.php" name="_wp_http_referer"/>
      </div>
      <div class="clear"/>
    </div>
    <div class="clear"/>
    <style>	







.fixed .column-comments {







width:8em;







}







	</style>
    <table cellspacing="0" class="widefat post fixed">
      <thead>
        <tr>
          <th style="" class="manage-column column-cb check-column" id="cb" scope="col"><input type="checkbox"/></th>
          <th style="" class="manage-column column-title" id="title" scope="col">Name</th>
          <th style="" class="manage-column column-author" id="author" scope="col">Last Name </th>
          <th style="" class="manage-column column-categories" id="categories" scope="col">Company Name </th>
          <th style="" class="manage-column column-tags" id="tags" scope="col">Email </th>
          <th style="" class="manage-column column-comments num" id="comments" scope="col"><div class="vers"> Picture </div></th>
          <th style="" class="manage-column column-date" id="date" scope="col">Date</th>
        </tr>
      </thead>
      <tfoot>
        <tr>
          <th style="" class="manage-column column-cb check-column" scope="col"><input type="checkbox"/></th>
          <th style="" class="manage-column column-title" scope="col">Name</th>
          <th style="" class="manage-column column-author" scope="col">Last Name </th>
          <th style="" class="manage-column column-categories" scope="col">Company Name </th>
          <th style="" class="manage-column column-tags" scope="col">Email</th>
          <th style="" class="manage-column column-comments num" scope="col"><div class="vers">Picture</div></th>
          <th style="" class="manage-column column-date" scope="col">Date</th>
        </tr>
      </tfoot>
      <tbody>
        <?php 







	global $wpdb;







	 $query_fet="Select * from ".$wpdb->prefix."members";



	$members = $wpdb->get_results($query_fet);


	if($members)







	foreach ($members as $member) {







	//$fname = stripslashes($member->fname);


	?>
        <tr valign="top" class="alternate author-self status-publish iedit" id="post-77">
          <th class="check-column" scope="row"><input type="checkbox" value="<?php echo $member->id; ?>" name="member[]"/></th>
          <td class="post-title column-title"><strong><a title='Edit "Home Page"' href="admin.php?page=add_members&action=edit&id=<?php echo $member->id; ?>" class="row-title"><?php echo $fname = stripslashes($member->fname);?></a></strong>
            <div class="row-actions"><span class="edit"><a title="Edit this post" href="admin.php?page=add_members&action=edit&id=<?php echo $member->id; ?>">Edit</a> | </span><span class="delete"><a onclick="if ( confirm('You are about to delete this User.') ) { return true;}return false;" href="?page=members/impxmltomysql.php&action=delete&id=<?php echo $member->id;?>" title="Delete this user" class="submitdelete">Delete</a> | </span></div></td>
          <td class="author column-author"><?php echo $member->lname;?></td>
          <td class="categories column-categories"><!--<a href="edit.php?category_name=uncategorized">-->
            <?php echo $member->company_name;?>
            <!-- </a>--></td>
          <td class="tags column-tags"><?php echo $member->email;?></td>
          <td class="comments column-comments"><!--<div class="post-com-count-wrapper">-->
            <img width="70"  height="104" src="../wp-content/uploads/<?php echo $member->title_image; ?>" />
            <!--</div>--></td>
          <td class="date column-date"><abbr title=""><?php echo $member->signup_date;?></abbr></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
    <div class="tablenav">
      <div class="alignleft actions">
        <select name="action2">
          <option selected="selected" value="-1">Bulk Actions</option>
          <option value="edit">Edit</option>
          <option value="delete">Delete</option>
        </select>
        <input type="submit" class="button-secondary action" id="doaction2" name="doaction2" value="Apply"/>
        <br class="clear"/>
      </div>
      <br class="clear"/>
    </div>
  </form>
  <div id="ajax-response"/>
  <br class="clear"/>
</div>
<script type="text/javascript">







	







/* <![CDATA[ */







(function($){







	$(document).ready(function(){







		$('#doaction, #doaction2').click(function(){







			if ( $('select[name^="action"]').val() == 'delete' ) {







				var m = 'You are about to delete the selected links.\n  \'Cancel\' to stop, \'OK\' to delete.';







				return showNotice.warn(m);







			}







		});







	});







})(jQuery);







columns.init('members');







/* ]]> */







</script>
<?php 







	}


	function mt_sublevel_page2() {



	echo "<h2>Test Sublevel 2</h2>";



	}



	?>
