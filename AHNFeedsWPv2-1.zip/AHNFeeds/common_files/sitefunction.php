<?php
/***********************************
	*
	* Created By: AHN Media
	* File Desc: Top Header of the page
	* Datd: 10-09-2008
	* Last Modified By: AHN Media
	* Copyright: AHN Media
	* Modified Date: 10-09-2010
	*   
	************************************/

/*function globalVariables(){
  
  foreach($_GET as $key => $value) {
	$$key = $value;
	}
  foreach($_POST as $key => $value) {
	$$key = $value;
	}
//  foreach($_SESSION as $key => $value) {
//	$$key = $value;
//	}
 } 
	*/


function publishUnpublish($tbl_name,$list,$action){

   global $mysql;
	if($action=='publish'){
	  $val=1;
	  
	}elseif($action=='unpublish'){
	  
	  $val=0;
	
	}
	if(is_array($list))
	foreach($list as $item){
	
	$isset=$mysql->record_update($tbl_name,array('status' => $val ),"id=".$item); 
		
	}
	$_SESSION["message"]=sizeof($list)." records ".$action."ed successfully";
	$_SESSION["t"]="success";
	
}	
	
function trashRestore($tbl_name,$list,$action){

   global $mysql;
	if($action=='trash'){
	  $val=1;
	  
	}elseif($action=='restore'){
	  
	  $val=0;
	
	}
	if(is_array($list))
	foreach($list as $item){
	$isset=$mysql->record_update($tbl_name,array('trash' => $val ),"id=".$item); 
		
	}
	if($action=="trash"){
	  $act="deleted";
	  }else{
	  $act="restored";
	  
	  }
	$_SESSION["message"]=sizeof($list)." records ".$action."ed successfully";
	$_SESSION["t"]="success";
}	

function CurrentUrl(){


$url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME']. $PHP_SELF."?".$_SERVER['QUERY_STRING'];

return $url;

}
	









	
function login_online($user_id){

	$qr="SELECT user_id FROM tbl_user_online WHERE user_id='".$user_id."'";
	$res = mysql_query($qr) or die(mysql_error());
	
	if(mysql_num_rows($res) == 0){
		$qr="INSERT INTO tbl_user_online SET user_id='$user_id', sid='".session_id()."', sys_ip='".$_SERVER['REMOTE_ADDR']."', date_login= now() ";
	}
	else{
		$qr="UPDATE tbl_user_online SET sid='".session_id()."', sys_ip='".$_SERVER['REMOTE_ADDR']."', date_login= now() WHERE user_id='$user_id'";	
	}
	
	mysql_query($qr) or die($qr);
}




function logout_online($user_id){

	$qr="DELETE FROM tbl_user_online WHERE user_id='".$user_id."'";
	$res = mysql_query($qr) or die(mysql_error());
}


// the first argument is page Number 2nd is rows per page 3rd is total record 
function pagination($pageNum,$maxRows,$totalRows){
	
	$url = "";
	$url .= $PHP_SELF."?".$_SERVER['QUERY_STRING']; 
	$pg=$_GET[pageNum];
	$url=str_replace('&pageNum='.$pg,'',$url);
	$startRow = $pageNum * $maxRows;
	$totalPages = ceil($totalRows/$maxRows);
	?>
	
	<div class="pagination" id="pagination" align="center"> Showing <?php echo ($startRow + 1) ?> to <?php echo min($startRow + $maxRows, $totalRows) ?> of <?php echo $totalRows ?> &nbsp; Record(s)&nbsp;&nbsp;&nbsp;&nbsp;Pages :: &nbsp;
	<?php 	if($pageNum>6&&$totalPages>10)	
	{	?> <a class="paging" href="<?php echo $url; ?>&pageNum=<?php echo '0' ?>" > <?php echo "[First]"; ?>
	</a> &nbsp; <?php } ?>	
	<?php if ($pageNum  > 0) {?>
	<a class="pagination" href="<?php echo $url; ?>&pageNum=<?php echo max(0, $pageNum - 1)?>" > [Previous]</a>
	<?php }?>
	&nbsp;&nbsp;
	<?php 
	if($pageNum>5){
	if($pageNum+5<$totalPages){	  
	$startPage=$pageNum-5;
	}elseif($totalPages >11){ 
	$startPage=($totalPages-10);  
	}else{$startPage=0;}
	}else $startPage=0;
	$count= $startPage;
	if($count+11<$totalPages){
	if($pageNum==0)
	$count= $count+10;
	else{ 
	$count= $count+11;
	}
	$showDot=1;
	}
	else {
	$count=$totalPages;
	$showDot =0;
	}
	
	for ($i=$startPage; $i< $count; $i=$i+1){
	if ($i!=$pageNum){
	?>
	<a class="paging" href="<?php echo $url; ?>&pageNum=<?php echo $i ?>"> <?php echo $i+1; ?>
	</a>
	<?php 
	}else{
	echo ("[". ($i + 1) ."]");
	}
	} 
	
	if($showDot==1){ echo "..."; }
	
	
	?>
	&nbsp;&nbsp;
	<?php 
	if ($pageNum < $totalPages - 1) 	{?>
	<a class="paging" href="<?php echo $url; ?>&pageNum=<?php echo min($totalPages, $pageNum + 1)?>">[Next] </a> &nbsp;
	<?php } 
	
	if($pageNum+6<$totalPages)	{	?> 
	<a class="paging" href="<?php echo $url; ?>&pageNum=<?php echo $totalPages-1 ?> "> <?php echo "[Last]"; ?></a> 					      &nbsp;
	<?php }
	?>  
	
	</div>
	<?php 
	
}// end pagination



 function dateDiff($dformat, $endDate, $beginDate)
    {
    $date_parts1=explode($dformat, $beginDate);
    $date_parts2=explode($dformat, $endDate);
    $start_date=gregoriantojd($date_parts1[0], $date_parts1[1], $date_parts1[2]);
    $end_date=gregoriantojd($date_parts2[0], $date_parts2[1], $date_parts2[2]);
    return $end_date - $start_date;
    }










function getTimeDiff($dtime){


	$dtimeArr = split(" ",$dtime);
	
	$start_date = $dtimeArr[0];
	$start_time = $dtimeArr[1];

	$guest_qry = mysql_query("select now() as time") or die(mysql_error());
	$guestime = mysql_fetch_array($guest_qry);

	$tmpdate = $guestime['time'];
	$tmpArr = split(" ",$tmpdate);
	
	$end_date = $tmpArr[0];
	$end_time = $tmpArr[1];; 

	$sdate=explode("-",$start_date);
	$stime=explode(":",$start_time);
	$edate=explode("-",$end_date);
	$etime=explode(":",$end_time);

	$d1 = mktime($stime[0],$stime[1],$stime[2],$sdate[1],$sdate[2],$sdate[0]);
	$d2 = mktime($etime[0],$etime[1],$etime[2],$edate[1],$edate[2],$edate[0]);
	
	return $d2-$d1;

}


function showMsg($msg,$type){
 ?>
 <style> 
 .success{


font-family: Tahoma;
	font-size: 11px;
	font-weight: bold;
    color:#02BBFE;   
   
	 
}

.er{
	font-family: Tahoma;
	font-size: 11px;
	font-weight: bold;
    color:#FF0000;   
     height:30px;
	 
}
 
 
 </style>
<?php
if($type=='error')
{?>

<?php
$msg='<div class="er"> <img src="graphics/error.gif" /> '.$msg.'</div>';

 }elseif($type=='success'){ ?>
<?php 
$msg='<div class="success"> <img src="graphics/yep.jpg" />'.$msg.'</div>';

}	

return $msg;	
}

function rating($rat){
		
		$full_stars= (int)$rat;
?>
		<table width="4" border="0" >
		
		<tr>
		<?php for($i = 0;$i < $full_stars;$i++){?>
			 <td> <img  src="graphics/stars/full.gif" />  </td>
		<?php 
		}
		
		$half_star= $rat - $full_stars;
		
		if($half_star!=0){
		
			if($half_star<0.5){
		?> 
				<td> <img src="graphics/stars/less.gif" /> </td>
				
		<?php 
				
			}elseif($half_star>0.5){
			
		?> 		<td> <img src="graphics/stars/greater.gif" /> </td> 
		<?php
			
			}elseif($half_star==0.5){
		?>
		
			<td> <img src="graphics/stars/half.gif" /> </td>
		<?php 
			}
		}
		if($half_star==0){
			$empty_stars=5-$full_stars;
		
		}else{
			$empty_stars=4-$full_stars;
		}
			for($i=0;$i<$empty_stars;$i++){
			
		?>	
			<td><img src="graphics/stars/empty.gif" /> </td> 
		<?php 
			
			}
		
		?>
		</tr></table>  
		<?php 
}








function deleteRecord($tbl_name,$where){
 global $mysql;
 return $mysql->record_delete($tbl_name,$where);
//	$query_del = "DELETE FROM ".$tbl_name . " WHERE ".$where;
		//$rec_del = mysql_query($query_del) or die(mysql_error());
}

function alterStatus($tbl_name,$where){
 global $mysql;
 //return $mysql->record_delete($tbl_name,$where);
	$query_alter = "Update ".$tbl_name . " set status=1-status WHERE ".$where;
//	echo $query_alter;
	return mysql_query($query_alter);
		//$rec_del = mysql_query($query_del) or die(mysql_error());
}

function trashRecord($tbl_name,$where){
 global $mysql;
 
	$query_alter = "Update ".$tbl_name . " set trash=1 WHERE ".$where;

	return mysql_query($query_alter);

}

function db_get_results($query){
	$results = array();
	$rs = mysql_query($query) or die(mysql_error());
	if(!$rs){
		//mysql_close($conn);
		return($results);
	}
	$rows = mysql_num_rows($rs);
	for($i=0;$i<$rows;$i++){
		$row = mysql_fetch_array($rs);
		while (list($key, $val) = each($row) ) {
			$results[$i][$key] = $val;
		}
	}
mysql_free_result($rs);
	//mysql_close($conn);
	
	return($results);
}


function mysqltonormal1($dated)
	{
		$dated = explode('-', $dated);
		$YYYY  = $dated[0];
		$MM = $dated[1];
		$DD = $dated[2];
		$final = $MM.'/'.$DD.'/'.$YYYY;
		if($final !='//'){
		return $final;		
		}
	}
	
function mysqltonormal2($dated)
	{
		$dated = explode('-', $dated);
		$YYYY  = $dated[0];
		$MM = $dated[1];
		$DD = $dated[2];
		$final = $MM.'/'.$DD.'/'.$YYYY;
		if($final !='//'){
		return $final;		
		}
	}	

	
	function mysqltonormal($dated)
	{
		$dated = explode('-', $dated);
		$YYYY  = $dated[0];
		$MM = $dated[1];
		$DD = $dated[2];
		$YY = substr($YYYY,2);
		$final = $MM.'/'.$DD.'/'.$YY;
		return $final;		
	}
	
	function normaltomysql($dated)
	{
		$dated = explode('/', $dated);
		$MM  = $dated[0];
		$DD = $dated[1];
		$YYYY = $dated[2];
		$final = $YYYY.'-'.$MM.'-'.$DD;
		if($final !='--') {
		return $final;		
		}
	}
	
	function siteRandom($no){
		$totalChar = $no;  //length of random number
		$salt = "abcdefghijklmnpqrstuvwxyz123456789";  // salt to select chars
		srand((double)microtime()*1000000); // start the random generator
		$password=""; // set the inital variable
		for ($i=0;$i<$totalChar;$i++)  // loop and create number
		$randnumber= $randnumber. substr ($salt, rand() % strlen($salt), 1);

		return $randnumber;
	}
	
	function stripslashes2($string) {
		$string = str_replace("\\\"", "\"", $string);
		$string = str_replace("\\'", "'", $string);
		$string = str_replace("\\\\", "\\", $string);
		return $string;
	}
	function replace_special_ch($data){
 	  $out_str = preg_replace("/^[^a-z0-9]?(.*?)[^a-z0-9]?$/i", "$1", $data);
	  return $out_str;
	  }


function xml2array($contents, $get_attributes=1)
{
	    
		if(!$contents) return array();

		if(!function_exists('xml_parser_create')) {
			//print "'xml_parser_create()' function not found!";
			return array();
		}
	
		
    //Get the XML parser of PHP - PHP must have this module for the parser to work
    $parser = xml_parser_create();
    xml_parser_set_option( $parser, XML_OPTION_CASE_FOLDING, 0 );
    xml_parser_set_option( $parser, XML_OPTION_SKIP_WHITE, 1 );
    xml_parse_into_struct( $parser, $contents, $xml_values );
    xml_parser_free( $parser );

//    if(!$xml_values) return;//Hmm... echo "Asdfasdf";exit;
    //Initializations
    $xml_array = array();
    $parents = array();
    $opened_tags = array();
    $arr = array();

    $current = &$xml_array;

    //Go through the tags.
    foreach($xml_values as $data) {
        unset($attributes,$value);//Remove existing values, or there will be trouble
        extract($data);//We could use the array by itself, but this cooler.

        $result = '';
        if($get_attributes) {//The second argument of the function decides this.
            $result = array();
            if(isset($value)) $result['value'] = $value;

            //Set the attributes too.
            if(isset($attributes)) {
                foreach($attributes as $attr => $val) {
                    if($get_attributes == 1) $result['attr'][$attr] = $val; //Set all the attributes in a array called 'attr'
                    /**  :TODO: should we change the key name to '_attr'? Someone may use the tagname 'attr'. Same goes for 'value' 

too */
                }
            }
        } elseif(isset($value)) {
            $result = $value;
        }

        //See tag status and do the needed.
        if($type == "open") {//The starting of the tag '<tag>'
            $parent[$level-1] = &$current;

            if(!is_array($current) or (!in_array($tag, array_keys($current)))) { //Insert New tag
                $current[$tag] = $result;
                $current = &$current[$tag];
				//echo $current.'sdff';

            } else { //There was another element with the same tag name
                if(isset($current[$tag][0])) {
                    array_push($current[$tag], $result);
                } else {
                    $current[$tag] = array($current[$tag],$result);
                }
                $last = count($current[$tag]) - 1;
                $current = &$current[$tag][$last];
            }

        } elseif($type == "complete") { //Tags that ends in 1 line '<tag />'
            //See if the key is already taken.
            if(!isset($current[$tag])) { //New Key
                $current[$tag] = $result;

            } else { //If taken, put all things inside a list(array)
                if((is_array($current[$tag]) and $get_attributes == 0)//If it is already an array...
                        or (isset($current[$tag][0]) and is_array($current[$tag][0]) and $get_attributes == 1)) {
                    array_push($current[$tag],$result); // ...push the new element into that array.
                } else { //If it is not an array...
                    $current[$tag] = array($current[$tag],$result); //...Make it an array using using the existing value and the new value
                }
            }

        } elseif($type == 'close') { //End of tag '</tag>'
            $current = &$parent[$level-1];
        }
    }	
    return($xml_array);
} 









/*
function xml2arrayNew($xml) {
        $xmlary = array();
               
        $reels = '/<(\w+)\s*([^\/>]*)\s*(?:\/>|>(.*)<\/\s*\\1\s*>)/s';
        $reattrs = '/(\w+)=(?:"|\')([^"\']*)(:?"|\')/';

        preg_match_all($reels, $xml, $elements);

        foreach ($elements[1] as $ie => $xx) {
                $xmlary[$ie]["name"] = $elements[1][$ie];
               
                if ($attributes = trim($elements[2][$ie])) {
                        preg_match_all($reattrs, $attributes, $att);
                        foreach ($att[1] as $ia => $xx)
                                $xmlary[$ie]["attributes"][$att[1][$ia]] = $att[2][$ia];
                }

                $cdend = strpos($elements[3][$ie], "<");
                if ($cdend > 0) {
                        $xmlary[$ie]["text"] = substr($elements[3][$ie], 0, $cdend - 1);
                }

                if (preg_match($reels, $elements[3][$ie]))
                        $xmlary[$ie]["elements"] = xml2array($elements[3][$ie]);
                else if ($elements[3][$ie]) {
                        $xmlary[$ie]["text"] = $elements[3][$ie];
                }
        }

        return $xmlary;
}

*/



function xml2ary_new(&$string) {
    $parser = xml_parser_create();
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
    xml_parse_into_struct($parser, $string, $vals, $index);
    xml_parser_free($parser);

    $mnary=array();
    $ary=&$mnary;
    foreach ($vals as $r) {
        $t=$r['tag'];
        if ($r['type']=='open') {
            if (isset($ary[$t])) {
                if (isset($ary[$t][0])) $ary[$t][]=array(); else $ary[$t]=array($ary[$t], array());
                $cv=&$ary[$t][count($ary[$t])-1];
            } else $cv=&$ary[$t];
            if (isset($r['attributes'])) {foreach ($r['attributes'] as $k=>$v) $cv['_a'][$k]=$v;}
            $cv['_c']=array();
            $cv['_c']['_p']=&$ary;
            $ary=&$cv['_c'];

        } elseif ($r['type']=='complete') {
            if (isset($ary[$t])) { // same as open
                if (isset($ary[$t][0])) $ary[$t][]=array(); else $ary[$t]=array($ary[$t], array());
                $cv=&$ary[$t][count($ary[$t])-1];
            } else $cv=&$ary[$t];
            if (isset($r['attributes'])) {foreach ($r['attributes'] as $k=>$v) $cv['_a'][$k]=$v;}
            $cv['_v']=(isset($r['value']) ? $r['value'] : '');

        } elseif ($r['type']=='close') {
            $ary=&$ary['_p'];
        }
    }    
    
    _del_p($mnary);
    return $mnary;
}

// _Internal: Remove recursion in result array
function _del_p(&$ary) {
    foreach ($ary as $k=>$v) {
        if ($k==='_p') unset($ary[$k]);
        elseif (is_array($ary[$k])) _del_p($ary[$k]);
    }
}

// Array to XML
function ary2xml($cary, $d=0, $forcetag='') {
    $res=array();
    foreach ($cary as $tag=>$r) {
        if (isset($r[0])) {
            $res[]=ary2xml($r, $d, $tag);
        } else {
            if ($forcetag) $tag=$forcetag;
            $sp=str_repeat("\t", $d);
            $res[]="$sp<$tag";
            if (isset($r['_a'])) {foreach ($r['_a'] as $at=>$av) $res[]=" $at=\"$av\"";}
            $res[]=">".((isset($r['_c'])) ? "\n" : '');
            if (isset($r['_c'])) $res[]=ary2xml($r['_c'], $d+1);
            elseif (isset($r['_v'])) $res[]=$r['_v'];
            $res[]=(isset($r['_c']) ? $sp : '')."</$tag>\n";
        }
        
    }
    return implode('', $res);
}

// Insert element into array
function ins2ary(&$ary, $element, $pos) {
    $ar1=array_slice($ary, 0, $pos); $ar1[]=$element;
    $ary=array_merge($ar1, array_slice($ary, $pos));
}





?>