=== FeedSyndicate Full Text News Article Importer ===
Contributors: ahncorp
Donate link: http://www.feedsyndicate.com/
Tags: news, content, newsml, rss, data, feedsyndicate, Feed Syndicate, news feeds, feeds
Requires at least: 2.0.2
Tested up to: 3.5.1
Stable tag: 3.5.1

The FeedSyndicate WordPress Plugin is a tool that will permit you to import full text news content from your FeedSyndicate account and insert it automatically into your WordPress website. 

== Description ==

The FeedSyndicate WordPress Plugin is a tool that will permit you to import packaged news content from your FeedSyndicate account and insert it directly into your WordPress site. 

Requires an active account from FeedSyndicate.com. Don't have one yet? No worries, we've created a special package just for WordPress users.  It includes full text news and weather at a special rate just for WordPress users.

Special Package for WordPress users - $49.99/mo
Highly discounted news and weather feeds designed just for WordPress users.  Includes all categories of news and images bundled with weather feeds.  News includes full text of the articles.

- Signup: https://www.feedsyndicate.com/servicequote/31303535443233315231323836


 
== Frequently Asked Questions ==

= What does this plugin do exactly? =

This plugin automatically downloads full text news articles, covering current top news, business and financial information from your FeedSyndicate.com account.

= Can it handle images? =

Yes.

= Does it use my page templates? =

Yes it uses your own WordPress page design.

= I don't have a FeedSyndicate Acccount. How can I signup? =

Don't worry, we've created a special news package just for WordPress users.  It includes full text news and weather at a special rate just for WordPress users.


Special Package for WordPress users - $49.99/mo
Highly discounted news and weather feeds designed just for WordPress users.  Includes all categories of news and images bundled with weather feeds.  News includes full text of the articles.

- Signup: https://www.feedsyndicate.com/servicequote/31303535443233315231323836


== Changelog ==

= 3.0 =
* Show the next auto import in the user's time and not always in GMT* Implement some blocking flag, so two import processes can't run at the same time* Much safer thumbnail handling/upload* add a setting in the admin to let the user select which author he wants to assign the cron import notes* If user sends a post to trash, draft or future, make sure we don't reimport.* Complete re-architect (OOP)* General cleanup* Speed improvements* + 10 security improvements and sanitization


= 2.0 =
* Updated logic due to WordPress coding issues.
* Minor bug fixes.


= 1.1 =
* Added logic to make article downloading times more consistent.
* Added hooks for future content types.


= 1.0 =
* Added additional downloading time options.
* Corrected a bug in old versions that prevented automatic updates.

= 0.5 =
* Beta release.

== Upgrade Notice ==

= 1.1 =
Version updated with additional features and a bug fix. Immediate update is recommended.


= 1.0 =
Version updated with additional features and a bug fix. Update is recommended.

= 0.5 =
This version had a bug that prevented the correct automatic downloading of content.

== Installation ==

To perform the install, you must begin by logging in to WordPress as the site administrator.

Once there, you will find the Plugins menu at the left of your page. Click the title to expand the box and show the options.

From the options, click to select Add New.

When the Install Plugins page appears, click the link titled Upload.

You will be presented with an upload form. Click the Browse... button and it will display a file open dialog. Use this to locate and double-click the installer packaged (named FeedSyndicate.zip)

When you return to the upload page, click Install Now. A few seconds later, the page will return with a message that the plugin has been installed successfully.

On this result page, you will see a link labeled Activate Plugin. Click this to finalize the process.

