<?php
/*
Plugin Name: FeedSyndicate Feeds
Plugin URI: http://www.feedsyndicate.com/software
Description: Plugin to import data from NewsML to wordpress database. Copyright FeedSyndicate
Version: 3.0
Author: FeedSyndicate
Author URI: http://www.feedsyndicate.com
*/

    define('FeedSyndicateFeeds_PATH', dirname(__FILE__));
    define('FeedSyndicateFeeds_URL', plugins_url('', __FILE__));

   
    require FeedSyndicateFeeds_PATH . '/helpers.php';
    require FeedSyndicateFeeds_PATH . '/cron_functions.php';
    require FeedSyndicateFeeds_PATH . '/FeedSyndicateFeeds.class.php';
    require FeedSyndicateFeeds_PATH . '/FeedSyndicateFeedsTable.class.php';
    
    $FeedSyndicate = new FeedSyndicateFeeds();

?>