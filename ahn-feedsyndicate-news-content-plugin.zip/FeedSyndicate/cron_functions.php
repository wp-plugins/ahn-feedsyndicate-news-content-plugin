<?php

add_action('AHNCronUpdate', 'AHNCronUpdate', 1, 1);

function AHNCronUpdate($feed_hash){
    add_option("Cron_step1", "true");
    $ah = new AHNFeeds();
    $ah->CronUpdate($feed_hash);
}

?>