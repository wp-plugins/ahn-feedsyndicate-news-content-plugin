<?php

    add_action('AHNCronUpdate', 'AHNCronUpdate', 10, 1);
    function FeedSyndicateCronUpdate($feed_hash){
        print_r($feed_hash);
        
        $ahn = new FeedSyndicateFeeds();
        $ahn->CronUpdate($feed_hash);
    }

?>
