<?php


if(!class_exists('WP_List_Table')){
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}


class AHNFeedsTable extends WP_List_Table {

    function __construct(){
        parent::__construct( array(
            'singular'  => 'feed',
            'plural'    => 'feeds',
            'ajax'      => true
        ) );
    }

    function get_columns(){
        $columns = array(
            'feed_title'     => __('Feed Title', "AHNFeeds"),
            'feed_url'    => __('Feed URL', "AHNFeeds"),
            'cat' => __('Category', "AHNFeeds"),
            'cron' => __('Next Auto Publish', "AHNFeeds")
        );
        return $columns;
    }

    function column_feed_title($item){

         $actions = array(
            'publish' => sprintf('<a onclick="updateFeed(\'%s\', true);" href="#">%s</a>',$item["hash"],__("Refresh and publish", "AHNFeeds")),
            'draft' => sprintf('<a onclick="updateFeed(\'%s\', false);" href="#">%s</a>',$item["hash"],__("Refresh and keep drafts", "AHNFeeds")),
            'delete' => sprintf('<a onclick="removeFeed(\'%s\');" href="#">%s</a>',$item["hash"],__("Remove", "AHNFeeds"))
        );
        return $item["feed_title"] . $this->row_actions($actions);

    }

    function column_feed_url($item){
          return $item["feed_url"];
    }

    function column_cat($item){
          $cat = $item["cat"];

          $oCat = get_category($cat);
          
          return $oCat->name;
    }

    function column_cron($item){

        $when = wp_next_scheduled("AHNCronUpdate", $item["hash"]);

        if (!$when){
            return __("Never", "AHNFeeds");
        }else{
            return date("F j, Y, g:i a", $when);
        }
    }

    function column_default($item){
        return $item;
    }


    function prepare_items() {

        $per_page = 20;

        $columns = $this->get_columns();
        $hidden = array();
        $sortable = array();

        $this->_column_headers = array($columns, $hidden, $sortable);

        $current_page = $this->get_pagenum();

        $this->items = get_option("AHNFeeds");


        $total_items = count($this->items);

        $this->set_pagination_args( array(
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items/$per_page) 
        ) );
    }


    function extra_tablenav( $which ) {
        if ($which == "top"){
            
    ?>
            <input class="button-secondary action" type="button" name="AHNPublishAll" id="AHNPublishAll" value="<?php _e("Refresh all and publish", "AHNFeeds"); ?>"/>
            <input class="button-secondary action" type="button" name="AHNDraftAll" id="AHNDraftAll" value="<?php _e("Refresh all as draft", "AHNFeeds"); ?>"/>
            <input class="button-secondary action" type="button" name="AHNRemoveAll" id="AHNRemoveAll" value="<?php _e("Remove all feeds", "AHNFeeds"); ?>"/>

    <?php
        }
    }
}
?>
