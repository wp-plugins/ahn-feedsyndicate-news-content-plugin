<?php

    class FeedSyndicateFeeds{

        private $page;


        public function __construct(){
            add_action("admin_menu", array($this, "admin_menu"));
            add_action("admin_init", array($this, "admin_init") );

            /* AJAX actions */
            add_action('wp_ajax_FeedSyndicateNewFeed', array($this, 'FeedSyndicateNewFeed'));
            add_action('wp_ajax_FeedSyndicateRemoveFeed', array($this, 'FeedSyndicateRemoveFeed'));
            add_action('wp_ajax_FeedSyndicateUpdateFeed', array($this, 'FeedSyndicateUpdateFeed'));
        }

        public function admin_print_styles(){
            wp_enqueue_script("thickbox");
            wp_enqueue_script("jquery-ui-dialog");

            wp_register_style("jquery-ui-css", plugins_url('jquery-ui-1.8.16.custom.css', __FILE__));
            wp_enqueue_style("jquery-ui-css");
        }

         /*
        * Hook for init action
        */
        public function admin_init(){
            load_plugin_textdomain( 'FeedSyndicateFeeds', false, FeedSyndicateFeeds_URL );
        }

        /*
        * Hook for the "remove" ajax call
        */
        public function FeedSyndicateUpdateFeed(){
            if (!isset($_POST["nonce"]) || !wp_verify_nonce($_POST["nonce"], 'FeedSyndicateNewFeed')){
                die("Security error!");
            }

            if ($_POST["publish"] == "true"){
                $status = "publish";
            }else{
                $status = "pending";
            }

            $feeds = array();
            if ($_POST["feed"] == "all"){
                $feeds = get_option("FeedSyndicateFeeds");
            }else{
                $feeds[] = $this->get_feed_from_hash($_POST["feed"]);
            }

            $inserted = 0;

            foreach ($feeds as $feed){

                $feed_content = $this->download_feed($feed);
               
	            $feed_array = xml2array($feed_content["body"],1);

                if (!empty($feed_array)){
                    foreach($feed_array['NewsML']['NewsItem'] as $NewsItem){
                        $post_data = $this->process_news_item($NewsItem);
                        $post_data["status"] = $status;
                        $post_data["category"] = $feed["cat"];
                        $inserted += $this->create_post_if_not_exist($post_data);
                    }
                }

                /*
                if ($feed["cron"] != "never"){
                    wp_reschedule_event( time(), $feed["cron"], 'FeedSyndicateCronUpdate', $feed["hash"]);
                }
                */

            }
            
            echo $inserted . __(" posts were inserted","FeedSyndicateFeeds");
            die();
        }

        /*
         *
         * Update by cron
         *
         */
        public function CronUpdate($hash){

            $feed = $this->get_feed_from_hash($hash);
            $feed_content = $this->download_feed($feed);

            $feed_array = xml2array($feed_content["body"],1);

            if (!empty($feed_array)){
                foreach($feed_array['NewsML']['NewsItem'] as $NewsItem){
                    $post_data = $this->process_news_item($NewsItem);
                    $post_data["status"] = "publish";
                    $post_data["category"] = $feed["cat"];
                    $this->create_post_if_not_exist($post_data);
                }
            }
         }


        /*
        * Hook for the "remove" ajax call
        */
        public function FeedSyndicateRemoveFeed(){

            if (!isset($_POST["nonce"]) || !wp_verify_nonce($_POST["nonce"], 'FeedSyndicateNewFeed')){
                die("Security error!");
            }

            if (isset($_POST["feed"])){
                if ($_POST["feed"] == "all"){
                    $this->_clear_cron_list();
                    delete_option("FeedSyndicateFeeds");
                }else{
                    $options = get_option("FeedSyndicateFeeds");
                    $cont = 0;
                    foreach ($options as $option){
                        if ($option["hash"] == $_POST["feed"]){

                            if ($option["cron"] != "never"){
                                $next = wp_next_scheduled( "FeedSyndicateCronUpdate", $option["hash"] );
                                if ($next){
                                    wp_unschedule_event( $next, 'FeedSyndicateCronUpdate', $option["hash"] );
                                }
                            }

                            unset($options[$cont]);
                            $options = array_values($options); //regenerate indexes
                            update_option("FeedSyndicateFeeds", $options);
                            break;
                        }
                        $cont++;
                    }

                }
            }

            $this->show_table();

            die();
        }

        /*
        * Hook for the "new feed" ajax call
        */
        public function FeedSyndicateNewFeed(){
            
            if (!isset($_POST["nonce"]) || !wp_verify_nonce($_POST["nonce"], 'FeedSyndicateNewFeed')){
                die("Security error!");
            }

            $feeds = get_option("FeedSyndicateFeeds");
            if (!$feeds) $feeds = array();

            $new_feed = array();


            $new_feed["feed_url"] = isset($_POST["feed_url"]) ? $_POST["feed_url"] : "";
            $new_feed["feed_title"] = isset($_POST["feed_title"]) ? $_POST["feed_title"] : "";
            $new_feed["cat"] = isset($_POST["cat"]) ? $_POST["cat"] : "";
            $new_feed["hash"] = md5($new_feed["feed_url"]);
            $new_feed["cron"] = isset($_POST["cron"]) ? $_POST["cron"] : "never";

            $feeds[] = $new_feed;

            update_option("FeedSyndicateFeeds", $feeds);

            if ($new_feed["cron"] != "never"){

                if (!wp_next_scheduled('FeedSyndicateCronUpdate', $new_feed["hash"])){
		            wp_schedule_event(time(), $new_feed["cron"], 'FeedSyndicateCronUpdate', $new_feed["hash"]);
                }
            }

            $this->show_table();

            die();

        }

       /*
        * Hook for the admin_head action for this page
        */
        public function admin_head(){
        ?>

                <script type="text/javascript" >


                function removeFeed(feed_id){
                    var data = {
                            action: 'FeedSyndicateRemoveFeed',
                            feed: feed_id,
                            nonce: jQuery("#FeedSyndicateNonce").val()
                    };

                    jQuery.post(ajaxurl, data, function(response) {
                       jQuery("#FeedSyndicateData").html(response);
                    });
                }

                function updateFeed(feed_id, shouldPublish){

                    jQuery( "#FeedSyndicateLoader" ).dialog({
                        modal:true,
                        height:100,
                        resizable:false
                    });

                    var data = {
                            action: 'FeedSyndicateUpdateFeed',
                            feed: feed_id,
                            publish: shouldPublish,
                            nonce: jQuery("#FeedSyndicateNonce").val()
                    };

                    jQuery.post(ajaxurl, data, function(response) {

                       jQuery("#FeedSyndicateNotices").html(response);

                       jQuery( "#FeedSyndicateLoader" ).dialog("close");

                       jQuery("#FeedSyndicateNotices").dialog({
                            modal:true,
                            height:100,
                            resizable:false
                        });



                    });
                }

                jQuery(document).ready(function() {



                    jQuery("#FeedSyndicateFeedsForm").submit( function(){

                        var data = {
                                action: 'FeedSyndicateNewFeed',
                                feed_url: jQuery("#form_feed_url").val(),
                                feed_title: jQuery("#form_feed_title").val(),
                                cat: jQuery("#form_cat").val(),
                                cron: jQuery('input[name=form_feed_cron]:checked', '#FeedSyndicateFeedsForm').val(),
                                nonce: jQuery("#FeedSyndicateNonce").val()
                        };


                        jQuery.post(ajaxurl, data, function(response) {
                           jQuery("#FeedSyndicateData").html(response);
                           jQuery("#form_feed_url").val("");
                           jQuery("#form_feed_title").val("");
                        });

                        return false;
                    });


                    jQuery("#FeedSyndicateRemoveAll").click(function(){
                        jQuery( "#delete-confirm" ).dialog({
                            resizable: false,
                            height:160,
                            modal: true,
                            buttons: {
                                "Delete all feeds": function() {
                                    removeFeed("all");
                                    jQuery( this ).dialog( "close" );
                                },
                                Cancel: function() {
                                    jQuery( this ).dialog( "close" );
                                }
                            }
                        });
                    });

                    jQuery("#FeedSyndicatePublishAll").click(function(){

                        updateFeed("all", true);

                    });

                    jQuery("#FeedSyndicateDraftAll").click(function(){

                        updateFeed("all", false);

                    });


                });

                </script>

        <?php
        }

       /*
        * Hook for the admin_menu action
        */
        public function admin_menu(){
            $this->page = add_menu_page( "FeedSyndicate Feeds", "FeedSyndicate", 'edit_posts', "FeedSyndicateFeeds", array($this, "admin_page"), FeedSyndicateFeeds_URL."/icon.png" );
            add_action('admin_print_styles-'.$this->page, array($this, "admin_print_styles") );
            add_action("admin_head-".$this->page, array($this, "admin_head"));
        }

       /*
        * Function that creates the FeedSyndicateFeeds administration page in the admin.
        */
        public function admin_page(){
            echo "<div class='wrap'>";

            echo "<div class='icon32'><img src='".FeedSyndicateFeeds_URL."/icon_big.png' /></div>";
            echo "<h2>" . __("NewsML Feeds", "FeedSyndicateFeeds") . "</h2>";
            echo "</div>";

            echo '<div style="display:none;" id="delete-confirm" title="' . __("Delete all feeds?", "FeedSyndicateFeeds") .'">';
	        echo '<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>' . __("These items will be permanently deleted and cannot be recovered. Are you sure?","FeedSyndicateFeeds") . '</p>';
            echo '</div>';

            echo "<div id='FeedSyndicateLoader' style='display: none;' title='" . __("Downloading news...", "FeedSyndicateFeeds") ."'>";
            echo "<center><img src='".FeedSyndicateFeeds_URL."/images/load.gif'/></center>";
            echo "</div>";

            echo "<div id='FeedSyndicateNotices' title='".__("Finished!","FeedSyndicateFeeds")."'>";
            echo "</div>";

            echo "<div id='FeedSyndicateData'>";
            $this->show_table();
            echo "</div>";

            $this->show_new_form();

        }


        public function show_table(){

            $table = new FeedSyndicateFeedsTable();
            $table->prepare_items();

            ?>
            <div class="wrap">
                <form id="topics-filter" method="get"">
                    <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
                    <?php $table->display() ?>
                </form>
            </div>

        <?php

        }

        protected function show_new_form(){

            echo "<form method='post' name='FeedSyndicateFeedsForm' id='FeedSyndicateFeedsForm'>";

            wp_nonce_field('FeedSyndicateNewFeed','FeedSyndicateNonce');
            ?>

            <div class="wrap">
                <div id="icon-edit" class="icon32 icon32-posts-topic"><br/></div>
                <h2><?php _e("Add new feed","FeedSyndicateFeeds"); ?></h2>
            </div>
            <table cellspacing="2" cellpadding="5" style="width: 100%;" class="form-table">
                <tbody>
                <tr>
                    <td width="21%"><strong><?php _e("Enter the NewsML Feed URL", "FeedSyndicateFeeds");?>:</strong></td>
                    <td width="79%"><input type="text" style="width:250px;" name="form_feed_url" id="form_feed_url" /></td>
                </tr>
                <tr>
                    <td width="21%"><strong><?php _e("Title of NewsML Feed", "FeedSyndicateFeeds");?>: </strong></td>
                    <td width="79%"><input type="text" style="width:250px;" name="form_feed_title" id="form_feed_title" /></td>
                </tr>
                <tr>
                    <td width="80"><strong><?php _e("Store this feed in Category", "FeedSyndicateFeeds");?>: </strong></td>
                    <td colspan="2"><?php wp_dropdown_categories('hide_empty=0&id=form_cat'); ?>
                    </td>
                </tr>
                <tr>
                    <td width="80" valign="top"><strong><?php _e("Auto Publish", "FeedSyndicateFeeds");?>: </strong></td>
                    <td colspan="2">
                        <input type="radio" name="form_feed_cron" value="never" checked/>&nbsp;Never<br/>
                        <input type="radio" name="form_feed_cron" value="hourly"/>&nbsp;Hourly<br/>
                        <input type="radio" name="form_feed_cron" value="twicedaily"/>&nbsp;Twice Daily<br/>
                        <input type="radio" name="form_feed_cron" value="daily"/>&nbsp;Daily
                    </td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td><input class="button-primary" type="submit" value="<?php _e("Add Feed", "FeedSyndicateFeeds");?>" name="Upload" id="Upload" /></td>
                </tr>
                </tbody>
            </table>
        <?php

        }

        private function get_feed_from_hash($hash){
            $options = get_option("FeedSyndicateFeeds");
            foreach ($options as $option){
                if ($option["hash"] == $hash){
                    return $option;
                }
            }
            return null;
        }

        private function download_feed($feed){

            $args = array(
                'method' => 'GET',
                'timeout' => 45,
                'redirection' => 10,
                'httpversion' => '1.0',
                'user-agent' => 'WordPress/FeedSyndicate-Plugin; ' . get_bloginfo( 'url' ),
                'blocking' => true,
                'headers' => array(),
                'cookies' => array(),
                'body' => null,
                'compress' => false,
                'decompress' => true,
                'sslverify' => false,
                'stream' => false,
                'filename' => null
            );

            $response = wp_remote_get( $feed["feed_url"], $args );
            if( is_wp_error( $response ) ) {
               return null;
            } else {
               return $response;
            }
        }

        private function process_news_item($newsitem){

            $data = array();

            $headline = $newsitem['NewsComponent']['NewsLines']['HeadLine']['value'];
            $ID =  $newsitem['Identification']['NewsIdentifier']['PublicIdentifier']['value'];

            $data["title"] = $headline;
            $data["ID"] = $ID;
        
            foreach ($newsitem['NewsComponent']['NewsComponent'] as $newscomponent){
                $data = $this->process_news_component($newscomponent, $data);
            }

            return $data;
        }

        private function process_news_component($newscomponent, $data){
            
            $excerpt = "";
            $content = "";
            $image = "";
            $image_title = "";

            if ( array_key_exists('Role', $newscomponent) ) {
				$excerpt = $newscomponent['ContentItem']['DataContent']['value'];
			} elseif ( array_key_exists('ContentItem', $newscomponent) ) {
				$content = $newscomponent['ContentItem']['DataContent']['value'];
			} elseif ( array_key_exists('NewsComponent', $newscomponent) ) {
				foreach ( $newscomponent['NewsComponent']  as $subitem ) {
					if (array_key_exists('Role', $subitem)){
                        if ($subitem['Role']['attr']['FormalName'] == 'Caption') {
                            $image_title = $subitem['ContentItem']['DataContent']['value'];
                        } elseif ($subitem['Role']['attr']['FormalName'] == 'JPG') {
                            $image = $subitem['ContentItem']['attr']['Href'];
                        }
                    }
				}
			}

			if ($excerpt != "") $data["excerpt"] = $excerpt;
			if ($content != "") $data["content"] = html_entity_decode($content);
			if ($image != "") $data["image"] = $image;
			if ($image_title != "") $data["image_title"] = $image_title;

			return $data;

        }

        private function create_post_if_not_exist($post_data){

            $meta_query = array(
                    array(
                        "key" => "_FeedSyndicateID",
                        "value" => $post_data["ID"],
                        "compare" => "="
                    )
            );

            $args = array();
            $args["meta_query"] = $meta_query;

            $existence = get_posts($args);

            if (empty($existence)){

                $post = array(
                    'post_category' => array($post_data["category"]),
                    'post_content' =>  $post_data["content"] ,
                    'post_excerpt' => $post_data["excerpt"],
                    'post_status' => $post_data["status"],
                    'post_title' => $post_data["title"]
                   );

                $post_id = wp_insert_post($post);

                if ($post_id){
                    update_post_meta($post_id, '_FeedSyndicateID', $post_data["ID"]);
                    $this->create_thumbnail($post_id, $post_data);
                }

                return 1;
            }
            return 0;
        }


        private function create_thumbnail($post_id, $post_data){

            if (isset($post_data["image"]) && $post_data["image"] != ""){

                $image = FeedSyndicateRemoteImageGrabber($post_id, $post_data["image"]);

                if ( is_object($image) && $image->errors ) {
                    return false;
                }

                if ( $post_data["image_title"] != "" ) {
                    $title= wp_kses($post_data["image_title"], array());
                }
                else {
                    $title = basename($image['file']);
                    if ( $dotpos= strpos($title, '.') )
                        $title= substr($title, 0, $dotpos);
                }
                $args = array(
                    'post_status'=>'publish', 'post_parent'=> $post_id, 'ping_status' =>'closed', 'guid'=>$image['url'], 'post_title'=> $title, 'post_mime_type'=>$image['content-type'] );

                $att_ID = wp_insert_attachment($args);

                if ( !$att_ID ) {
                    return false;
                }

                if (!function_exists("wp_generate_attachment_metadata")){
                    require_once $this->get_wp_config_path() . "/wp-admin/includes/image.php";
                }

                wp_update_attachment_metadata($att_ID, wp_generate_attachment_metadata($att_ID, $image['file']));

                update_attached_file($att_ID, $image['file']);

                update_post_meta($post_id, '_thumbnail_id', $att_ID, true);

                return true;
            }
            return null;
        }

        private function get_wp_config_path()
        {
            $base = dirname(__FILE__);
            $path = false;

            if (@file_exists(dirname(dirname($base))."/wp-config.php"))
            {
                $path = dirname(dirname($base))."";
            }
            else
            if (@file_exists(dirname(dirname(dirname($base)))."/wp-config.php"))
            {
                $path = dirname(dirname(dirname($base)))."";
            }
            else
            $path = false;

            if ($path != false)
            {
                $path = str_replace("\\", "/", $path);
            }
            return $path;
        }

        private function _clear_cron_list(){
        
            $feeds = get_option("FeedSyndicateFeeds");

            foreach ($feeds as $feed){

                if ($feed["cron"] != "never"){
                    $next = wp_next_scheduled( "FeedSyndicateCronUpdate", $feed["hash"] );
                    if ($next){
                        wp_unschedule_event( $next, 'FeedSyndicateCronUpdate', $feed["hash"] );
                    }
                }
            }
        }
    }
?>