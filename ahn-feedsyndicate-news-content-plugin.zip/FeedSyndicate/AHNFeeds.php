<?php
/*
Plugin Name: FeedSyndicate Feeds
Plugin URI: http://www.feedsyndicate.com/software
Description: Plugin to import data from NewsML to wordpress database. Copyright AHN
Version: 3.0
Author: FeedSyndicate
Author URI: http://www.feedsyndicate.com
*/

    define('AHNFeeds_PATH', dirname(__FILE__));
    define('AHNFeeds_URL', plugins_url('', __FILE__));

   
    require AHNFeeds_PATH . '/helpers.php';
    require AHNFeeds_PATH . '/cron_functions.php';
    require AHNFeeds_PATH . '/AHNFeeds.class.php';
    require AHNFeeds_PATH . '/AHNFeedsTable.class.php';

    $AHN = new AHNFeeds();

?>